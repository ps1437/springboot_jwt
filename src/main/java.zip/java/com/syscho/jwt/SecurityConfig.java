package com.syscho.jwt;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.Http401AuthenticationEntryPoint;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserDetailsImpl userDetailsService;
	@Autowired
	private ObjectMapper objectMapper;

	@Bean
	public NoOpPasswordEncoder encoder() {
		return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {

		auth.userDetailsService(userDetailsService).passwordEncoder(encoder());

	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		/*
		 * http.sessionManagement().maximumSessions(1).maxSessionsPreventsLogin(
		 * true); http.httpBasic(); http.csrf().disable();
		 * http.authorizeRequests().antMatchers("/resurces","/loginPage").
		 * permitAll(). anyRequest().authenticated().and().formLogin()
		 * .loginPage("/login.html")
		 * .usernameParameter("userName").passwordParameter("password").
		 * permitAll().and( ).logout().permitAll();
		 */
		http.sessionManagement().maximumSessions(1).maxSessionsPreventsLogin(false).expiredUrl("/expired");
		http.cors();
		/*
		 * http.authorizeRequests().antMatchers("/resources/**",
		 * "/loginPageMAin").permitAll() .anyRequest().authenticated()
		 * //.and().formLogin() // .usernameParameter("userName") //
		 * .passwordParameter("password")
		 * //.loginPage("/login").loginProcessingUrl("/loginPage")
		 * .and().formLogin().usernameParameter("username")
		 * .successHandler(this::loginSuccessHandler)
		 * .failureHandler(this::loginFailureHandler).successForwardUrl(
		 * "/success").failureForwardUrl("/failed")
		 * .permitAll().and().logout().logoutSuccessHandler(this::
		 * logoutSuccessHandler).permitAll(); http.httpBasic();
		 * http.csrf().disable();
		 */

	   	http.csrf().disable().authorizeRequests().anyRequest().authenticated()
	   	.and().formLogin().loginPage("/login").loginProcessingUrl("/login")

				// .and()
				// .formLogin()
				// .loginProcessingUrl("/login")
				// .usernameParameter("login")
				// .passwordParameter("password")
				// .successHandler(this::loginSuccessHandler)
				// .failureHandler(this::loginFailureHandler)

			//	.and().addFilterBefore(authenticationFilter(), UsernamePasswordAuthenticationFilter.class)
				.and().logout()
				.logoutUrl("/logout").logoutSuccessHandler(this::logoutSuccessHandler)

				.and().exceptionHandling()
				.authenticationEntryPoint(new Http401AuthenticationEntryPoint("401"));

	}

	

	private void loginSuccessHandler(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException {

		response.setStatus(HttpStatus.OK.value());
		objectMapper.writeValue(response.getWriter(), "Yayy you logged in!");
	}

	private void loginFailureHandler(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException e) throws IOException {

		System.out.println("SecurityConfig.loginFailureHandler()");
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		objectMapper.writeValue(response.getWriter(), "Nopity nop!");
	}

	private void logoutSuccessHandler(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException {

		response.setStatus(HttpStatus.OK.value());
		objectMapper.writeValue(response.getWriter(), "Bye!");
	}

/*	@Bean
	public AuthFilter authenticationFilter() throws Exception {
		AuthFilter authenticationFilter = new AuthFilter();
		authenticationFilter.setAuthenticationSuccessHandler(this::loginSuccessHandler);
		authenticationFilter.setAuthenticationFailureHandler(this::loginFailureHandler);
		authenticationFilter.setRequiresAuthenticationRequestMatcher(new AntPathRequestMatcher("/login", "POST"));
		authenticationFilter.setAuthenticationManager(authenticationManagerBean());
		return authenticationFilter;
	}
*/
}
