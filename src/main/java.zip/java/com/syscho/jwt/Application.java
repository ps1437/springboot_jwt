package com.syscho.jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.syscho.*" })
public class Application {

	public static void main(String[] args) {

		SpringApplication.run(Application.class, args);
	}
}
