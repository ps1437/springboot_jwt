package com.syscho.jwt;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.syscho.jwt.rest.vo.LoginVo;
import com.syscho.jwt.rest.vo.UserVo;

@Service
public class UserDetailsImpl implements UserDetailsService {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		
		System.out.println("UserDetailsImpl.loadUserByUsername() : :  "+username);
		LoginVo query = jdbcTemplate.query("SELECT * FROM USER WHERE USER_ID = ?", new Object[] { username },
				new ResultSetExtractor<LoginVo>() {

					public LoginVo extractData(ResultSet res) throws SQLException, DataAccessException {
						LoginVo vo = null;

						if (res.next()) {
							vo = new LoginVo();
							vo.setUsername(res.getString("USER_ID"));
							vo.setPassword(res.getString("PASSWORD"));

						}
						// TODO Auto-generated method stub
						return vo;
					}

				});
		
		
		
		
		if(null ==query){
			throw new UsernameNotFoundException("USER NOT FOUND");
		}

		return new UserVo(query.getUsername(), query.getPassword());
		// new User(query.getUserName(), query.getPassword(), true, true, true, true,
		// Collections.<GrantedAuthority>emptyList());

	}

}
