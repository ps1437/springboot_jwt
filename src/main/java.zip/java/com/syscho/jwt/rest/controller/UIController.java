package com.syscho.jwt.rest.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UIController {

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {

		System.out.println("Main.login() : error" + error);
		return "login";
	}

	@RequestMapping(value = "/failed", method = RequestMethod.GET)
	public String failed(Model model, String error, String logout) {

		model.addAttribute("msg", "Invalid CREDENTIALS");

		return "login";
	}

	@RequestMapping(value = "/expired", method = RequestMethod.GET)
	public String expired(Model model, String error, String logout) {

		model.addAttribute("msg", "SOMEONE HACKED");

		return "login";
	}
}
