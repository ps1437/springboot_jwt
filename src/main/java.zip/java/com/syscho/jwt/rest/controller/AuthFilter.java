/*package com.syscho.jwt.rest.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.syscho.jwt.rest.vo.LoginVo;

public class AuthFilter extends UsernamePasswordAuthenticationFilter {

	private final ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException {
		Authentication authenticate = null;
		String requestBody;

		try {
			String parameter = request.getParameter("username");
			String parameter2 = request.getParameter("password");
			System.out.println("AuthFilter.attemptAuthentication()" + parameter);
			System.out.println("AuthFilter.attemptAuthentication()" + parameter2);

			requestBody = IOUtils.toString(request.getReader());
			LoginVo authRequest = objectMapper.readValue(requestBody, LoginVo.class);

			System.out.println(authRequest);

			UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
					authRequest.getUsername(), authRequest.getPassword());

			setDetails(request, token);
			authenticate = this.getAuthenticationManager().authenticate(token);
		} catch (Exception exp) {

			System.out.println("AuthFilter.enclosing_method() EXEROOOOOOOOOOOOOOOOOOOOO:" + exp);
		}
		return authenticate;
	}

}
*/