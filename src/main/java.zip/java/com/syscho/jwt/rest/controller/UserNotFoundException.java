package com.syscho.jwt.rest.controller;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class UserNotFoundException {

	@ExceptionHandler(BadCredentialsException.class)
	public String authErro() {
		return "INVALID CRED";
	}
}
