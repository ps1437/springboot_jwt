package com.syscho.jwt.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.syscho.jwt.rest.vo.LoginVo;

@RestController
public class LoginController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping("/loginPageMAin")
	public Authentication authenticate(@RequestBody LoginVo loginVo) {
		Authentication authentication = null;
		System.out.println("LoginController.authenticate()");
		authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(loginVo.getUsername(), loginVo.getPassword()));
		System.out.println("authentication: " + authentication);
		return authentication;
	}

	@CrossOrigin(origins="http://localhost:3006")
	@RequestMapping(value = "/success")
	public Authentication success(Model model, String error, String logout) {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		return authentication;
	}

	@RequestMapping(value = "/expiredd", method = RequestMethod.GET)
	public String expired(Model model, String error, String logout) {

		

		System.out.println("Main.expired()");

		return "expired";
	}

}
